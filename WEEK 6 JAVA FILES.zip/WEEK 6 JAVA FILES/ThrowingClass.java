public class ThrowingClass {
	static void meth() throws ClassNotFoundException {
		throw new ClassNotFoundException ("demo");
	}
}

