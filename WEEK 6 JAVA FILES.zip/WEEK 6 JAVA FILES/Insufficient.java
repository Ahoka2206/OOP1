public class Insufficient extends Exception{
	public Insufficient(){
		super("Insufficient funds.");
	}
}