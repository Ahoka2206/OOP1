public class ExceptionLineTooLong e Exception{
	public ExceptionLineTooLong(){
		super("The strings is too long.");
	}
}