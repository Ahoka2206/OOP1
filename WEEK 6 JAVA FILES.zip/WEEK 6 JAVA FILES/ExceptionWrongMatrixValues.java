class ExceptionWrongMatrixValues extends Exception{
	public ExceptionWrongMatrixValues(){
		super("ExceptionWrongMatrixValues");
	}
}