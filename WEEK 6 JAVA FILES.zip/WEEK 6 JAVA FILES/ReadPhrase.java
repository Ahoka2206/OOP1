import java.util.*;

public class ReadPhrase{

	public static void main(String args[]) {
		Scanner input = new Scanner(System.in);
		String phrase;

		try {
			phrase = input.nextLine();
			if (phrase.length() < 80)
				System.out.println(phrase);
			else
				throw new ExceptionLineTooLong();
		}catch (Exception ex){
			System.out.println("The strings is too long.");
		}

	}
}