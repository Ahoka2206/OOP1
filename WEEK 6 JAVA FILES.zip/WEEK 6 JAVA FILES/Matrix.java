public class Matrix{
    private int matrix[][];

    public Matrix(){}

    public Matrix(int row, int column){
        matrix = new int[row][column];
    }

    //your methods here
    public void read(String numbers){
		int in;
		int last;
		String newnum;
		try {
			String a[] = numbers.split(".");

			in = numbers.indexOf('.');
			last = numbers.lastIndexOf('.');

			//System.out.println(in - 1);
			//System.out.println(last - in) ;
			//System.out.println(in % last) ;

			if (!(numbers.contains(".")))//for period oks na ni
				throw new ExceptionWrongMatrixDimension();

			if(last % in == 0)//para sa kinalasan ug second tc
				throw new ExceptionWrongMatrixValues();


			for (int i = numbers.length() - 1; i > 0; i--){//letter
				if ((Character.isLetter(numbers.charAt(i)) == true))
			    	throw new ExceptionWrongMatrixValues();
            }

			numbers = numbers.replace(" . ", "\n");
			numbers = numbers.replace(".", "");
			System.out.println(numbers);

		}catch (ExceptionWrongMatrixValues ex) {
			System.out.println("ExceptionWrongMatrixValues");
		}catch (ExceptionWrongMatrixDimension ex) {
			System.out.println("ExceptionWrongMatrixDimension");
		}catch (Exception ex) {
			System.out.println(ex);
		}
	}
}