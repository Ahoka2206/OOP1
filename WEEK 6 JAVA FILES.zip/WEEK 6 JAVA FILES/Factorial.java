import java.util.*;

public class Factorial{
	public static void main(String args[]) {
		Scanner input = new Scanner(System.in);
		int number, factorial;
		try{
			number = input.nextInt();
			factorial = 1;
			if (number > 1){
				for(int i = 1; i <= number; i++){
					factorial *= i;
				}
				System.out.println(factorial);
			}else{
				System.out.println("Invalid Input");
			}
		}catch(InputMismatchException e) {
			System.out.println("InputMismatchException");
		}
	}
}
