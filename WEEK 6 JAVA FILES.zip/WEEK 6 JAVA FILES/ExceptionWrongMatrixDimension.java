class ExceptionWrongMatrixDimension extends Exception{
	public ExceptionWrongMatrixDimension(){
		super("ExceptionWrongMatrixDimension");
	}
}