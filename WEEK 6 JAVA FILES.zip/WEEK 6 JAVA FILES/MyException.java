public class Insufficient extends Exception{
	public MyException(){
		super("Insufficient funds.");
	}
}