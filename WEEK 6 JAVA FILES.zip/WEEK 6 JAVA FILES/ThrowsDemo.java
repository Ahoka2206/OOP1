public class ThrowsDemo {
	public static void main(String args[]) {
		try {
			ThrowingClass.meth();
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		}
	}
}

