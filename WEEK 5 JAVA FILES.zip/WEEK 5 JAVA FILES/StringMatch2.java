import java.util.*;

public class StringMatch{
	private String sentence;
	private String word;

	//contructors
	public StringMatch(){}

	public StringMatch(String sentence, String word){
		this.sentence = sentence;
		this.word = word;
	}

	//setters
	public void setSentence(String sentence){
		this.sentence = sentence;
	}

	public void setPattern(String word){
		this.word = word;
	}

	//getters
	public String getSentence(){
		return sentence;
	}

	public String getPattern(){
		return word;
	}

	//methods
	public String match(String sentence, String pattern){
		String finalString = " ";
		String replaced = sentence.replace(",", " "); //giilisdan ang comma ug space para dali ra ang pag check, kay mao man given hehe
		String a[] = replaced.split(" ");

		for (int i = a.length - 1; i > 0; i--){
			if (word.equals(a[i])){//uban sa string way labot comma, separted by space rani
				a[i] = word.toUpperCase();//uppercase ang word
					count++;
			}
		}

		 for(String yars: a) {//combine though wa pa ni comma
			finalString += yars + " ";
		}

		finalString = finalString.replace("  ", ", ");//balik ang original nawng sa string
		return finalString;
	}

	public int countOccurance(String sentence, String pattern){
		String replaced = sentence.replace(",", " "); //giilisdan ang comma ug space para dali ra ang pag check, kay mao man given hehe
		String a[] = replaced.split(" ");

		for (int i = a.length - 1; i > 0; i--){
			if (word.equals(a[i])){//uban sa string way labot comma, separted by space rani
				a[i] = word.toUpperCase();//uppercase ang word
				count++;
			}
   	 	}
		return count;
	}

	public static void main (String [] args){
		StringMatch2 s = new StringMatch2();
		 String sentence;
		 String pattern;

		 System.out.print("Text string: ");
		 sentence = input.nextLine();
		 System.out.print("Pattern string: ");
       	 word = input.nextLine();

       	 s.setSentence(sentence);
       	 s.setPattern(pattern);
       	 System.out.println(s.match);
       	 System.out.println("Number of Occurence: " + s.countOccurance);
	}
}
