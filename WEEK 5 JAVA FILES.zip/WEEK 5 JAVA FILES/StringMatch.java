import java.util.*;

public class StringMatch{
	private String sentence;
	private String pattern;

	//contructors
	public StringMatch(){}

	public StringMatch(String sentence, String pattern){
		this.sentence = sentence;
		this.pattern = pattern;
	}

	//setters
	public void setSentence(String sentence){
		this.sentence = sentence;
	}

	public void setWord(String pattern){
		this.pattern = pattern;
	}

	//getters
	public String getSentence(){
		return sentence;
	}

	public String getPattern(){
		return pattern;
	}

	//methods
	public String match(String sentence, String pattern){
		String finalString = " ";
		String replaced = sentence.replace(",", " "); //giilisdan ang comma ug space para dali ra ang pag check, kay mao man given hehe
		String a[] = replaced.split(" ");
		int count = 0;

		for (int i = a.length - 1; i > 0; i--){
			if (pattern.equals(a[i])){//uban sa string way labot comma, separted by space rani
				a[i] = pattern.toUpperCase();//uppercase ang word
					count++;
			}
		}

		 for(String yars: a) {//combine though wa pa ni comma
			finalString += yars + " ";
		}

		finalString = finalString.replace("  ", ", ");//balik ang original nawng sa string
		return finalString;
	}

	public int countOccurance(String sentence, String pattern){
		String replaced = sentence.replace(",", " "); //giilisdan ang comma ug space para dali ra ang pag check, kay mao man given hehe
		String a[] = replaced.split(" ");
		int count = 0;

		for (int i = a.length - 1; i > 0; i--){
			if (pattern.equals(a[i])){//uban sa string way labot comma, separted by space rani
				a[i] = pattern.toUpperCase();//uppercase ang word
				count++;
			}
   	 	}
		return count;
	}

	public static void main (String [] args){
		StringMatch s = new StringMatch();
		String sentence;
		String pattern;

		Scanner input = new Scanner(System.in);
		sentence = input.nextLine();
		pattern = input.nextLine();

		System.out.println("New Text:" + s.match(sentence, pattern));
       	System.out.println("Number of Occurence: " + s.countOccurance(sentence, pattern));

	}
}
