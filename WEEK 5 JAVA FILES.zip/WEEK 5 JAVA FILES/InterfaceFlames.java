interface InterfaceFlames{
	public int countLetters(String name1, String name2);
	public char flames(int numLetters);
	public String letterEquivalent(char flames);
}