import java.util.*;
public class Test{
	private String sentence;

	public Test(){}

	public void fullName (String name){
		String lname = "";
		String aname = "";

		for(int i = 0; i <= name.length() - 1; i++){
			char ch = name.charAt(i);
			if(ch != ' '){
				lname += ch;
			}else{
			    aname += lname.charAt(0);
			    aname += '.';
				lname = "";
			}
		}

		String lastname = "";
		for (int j = 0; j < lname.length(); j++) {
		   if (j == 0)
		   		lastname = lastname + Character.toUpperCase(lname.charAt(0));
			else
				lastname = lastname + Character.toLowerCase(lname.charAt(j));
		}
		String finalname = aname + lastname;
			System.out.println(finalname);

	}


	public static void main (String [] args){
		Scanner input = new Scanner(System.in);
		Test t = new Test();
		String sentence;
		sentence = input.nextLine();
		t.fullName(sentence);
	}
}