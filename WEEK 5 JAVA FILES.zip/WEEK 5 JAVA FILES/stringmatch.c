#include <stdio.h>
#include <string.h>
#include <ctype.h>
#define MAX 100

void Upper(char[], char[], int);
int Checking(char[],char[]);

int main(){
    char str[MAX], final[MAX], word[MAX];
    int i = 0, j = 0, count = 0, flag = 0;
    
    printf("\nSTRING MATCH!!\n\n");
    printf("Text string: ");
    gets(str);
    printf("Pattern string: ");
    gets(word);

    do {
        if (str[i] != ' ') {
            final[j] = str[i];
            ++j;
            final[j] = '\0';
            if (Checking(final, word) && !isalnum(str[i+1] ))
                flag = 1;   
        } 
        else 
        j=0;
        

        if (flag == 1){
            ++count; 
            Upper(str, word, i);  
            j=0;
        }
        flag = 0;
        i++;
    }while (str[i] != '\0');

    printf("\nNew Text: %s\n", str);
    printf("Number of occurrence: %d", count);
    return 0;
}

void Upper(char str[], char word[],  int i){
    int k;
    for (k = 0; k < strlen(word); k++){
        str[i - k] = toupper(str[i - k]);
    }
}

int Checking(char final[], char word[]){
    if (strcmp(final, word) == 0){
        return 1;
    }
    return 0;
}
