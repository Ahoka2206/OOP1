public class NewTest{
	public static void main (String [] args){

	ImpFlames f = new ImpFlames();
	int x= f.countLetters("SamAntha","Alexander");
	System.out.println(f.flames(x));
System.out.println(f.letterEquivalent(f.flames(x)));
}
}